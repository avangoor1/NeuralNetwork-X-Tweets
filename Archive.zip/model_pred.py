import pandas as pd

import torch
from torch.utils.data import Dataset, DataLoader

from keras._tf_keras.keras.preprocessing import sequence
from keras._tf_keras.keras.preprocessing.text import Tokenizer

from model_training import DatasetMapper, Model, HYPERPARAMETERS

CSV_NO_IDS_FILENAME = "./tweets_no_ids.csv"

def load_saved_model(filename: str) -> Model:
    components = filename.split("_")
    VOCAB_SIZE = components[-1]
    model = Model(
        HYPERPARAMETERS["EMBEDDING_DIM"],
        HYPERPARAMETERS["NUM_HIDDEN_NODES"],
        HYPERPARAMETERS["NUM_LAYERS"],
        HYPERPARAMETERS["BIDIRECTION"],
        HYPERPARAMETERS["DROPOUT"]
    )
    model.load_state_dict(torch.load(filename))
    model.to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    # Make sure to set model to evaluation mode, not training
    model.eval()
    return model

def load_tokenizer() -> Tokenizer:
    csv_data = pd.read_csv(CSV_NO_IDS_FILENAME)

    X = csv_data['content'].values
    Y = csv_data['class'].values

    tokenizer = Tokenizer(num_words=10000)
    tokenizer.fit_on_texts(X)
    return tokenizer

def predict(model: Model, input_filename: str):
    # Read in data in same format and tokenization as training data was.
    csv_data = pd.read_csv(input_filename, header=None)

    # Print each string from the CSV file
    print("Input strings:")
    for index, text in enumerate(csv_data[0].values):
        print(f"Row {index + 1}: {text}")

    num_inputs = csv_data[0].size
    dummy_y = [0 for _ in range(num_inputs)]

    tokenizer = load_tokenizer()

    input_sequences = tokenizer.texts_to_sequences(csv_data[0].values)
    padded_input = sequence.pad_sequences(input_sequences, maxlen=csv_data[0].str.len().max())

    inference_set = DatasetMapper(padded_input, dummy_y)

    BATCH_SIZE = 64
    inference_loader = DataLoader(inference_set, batch_size=BATCH_SIZE)

    # input_data = torch.tensor(padded_input)
    # input_data = torch.squeeze(input_data, 0)

    # print(input_data, input_data.size())

    model.eval()
    prediction_accumulator = []
    for inference_input, _ in inference_loader:
        with torch.no_grad():
            predictions = model(inference_input)
            prediction_accumulator.append(predictions)
    return prediction_accumulator

if __name__ == "__main__":
    MODEL_FILENAME = "TrainedModel_2024-11-04_0.667.pt" # Chosen from saved models
    INPUT_FILENAME = "test_tweets.csv" # One Column, Header of "content"
    model: Model = load_saved_model(MODEL_FILENAME)

    predictions = predict(model, INPUT_FILENAME)

    # Do something with predictions
    print(predictions)